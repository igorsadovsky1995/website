$(document).ready(function(){
   $('.slider-content__row').slick({
      dots: true,
      arrows:false,
      speed: 300,
      slidesToShow: 1,
   });
   
});