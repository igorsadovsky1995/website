$(document).ready(function(){
   
   $('.skills-slider__row').slick({
         
      slidesToScroll: 1,
      dots: true,
      adaptiveWidth:false,
      infinite:false,
      touchThreshold:5,
      centerMode:false,
      variableWidth:true,
   }); 
   
})